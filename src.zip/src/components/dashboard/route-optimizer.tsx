"use client"

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Address, supabase } from '@/lib/supabase'
import { Loader2, Route, RotateCw, Clock, TrendingDown, Play, DollarSign, Download, Home } from 'lucide-react'
import { useToast } from '@/components/ui/use-toast'
import { useAuth } from '@/contexts/auth-context'
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

type RouteOptimizerProps = {
  addresses: Address[]
  onOptimizeRoute: (optimizedAddresses: Address[]) => void
}

type DistanceMatrix = {
  [key: string]: {
    [key: string]: {
      distance: number // in meters
      duration: number // in seconds
    }
  }
}

export function RouteOptimizer({ addresses, onOptimizeRoute }: RouteOptimizerProps) {
  const [isOptimizing, setIsOptimizing] = useState(false)
  const [isExporting, setIsExporting] = useState(false)
  const [distanceMatrix, setDistanceMatrix] = useState<DistanceMatrix>({})
  const [startingAddressId, setStartingAddressId] = useState<string>("")
  const [optimizationStats, setOptimizationStats] = useState<{
    totalDistance: number
    totalDuration: number
    improvementPercentage: number
    laborCost: number
  } | null>(null)
  const [hourlyCost, setHourlyCost] = useState<number>(25) // Default hourly cost
  const { toast } = useToast()
  const { user } = useAuth()

  // Load user settings
  useEffect(() => {
    const loadUserSettings = async () => {
      if (!user) return
      
      try {
        const { data, error } = await supabase
          .from('user_settings')
          .select('hourly_cost')
          .eq('user_id', user.id)
          .single()
        
        if (error && error.code !== 'PGRST116') { // PGRST116 is "not found" error
          throw error
        }
        
        if (data) {
          setHourlyCost(data.hourly_cost || 25)
        }
      } catch (error) {
        console.error('Error loading user settings:', error)
      }
    }
    
    loadUserSettings()
  }, [user])

  // Set the first address as the default starting address when addresses change
  useEffect(() => {
    if (addresses.length > 0 && !startingAddressId) {
      setStartingAddressId(addresses[0].id)
    }
  }, [addresses])

  // Function to calculate distances between all addresses using Google Distance Matrix API
  const calculateDistanceMatrix = async (addresses: Address[]) => {
    if (!window.google || !window.google.maps) {
      toast({
        title: "Error",
        description: "Google Maps API is not loaded",
        variant: "destructive"
      })
      return null
    }

    if (addresses.length < 2) {
      toast({
        title: "Not enough addresses",
        description: "You need at least 2 addresses to optimize a route",
        variant: "destructive"
      })
      return null
    }

    const service = new google.maps.DistanceMatrixService()
    const matrix: DistanceMatrix = {}

    // Create a matrix of all possible origin-destination pairs
    for (let i = 0; i < addresses.length; i++) {
      const origin = addresses[i]
      matrix[origin.id] = {}

      // Process in batches of 10 destinations (API limit)
      for (let j = 0; j < addresses.length; j += 10) {
        const batchDestinations = addresses.slice(j, j + 10)
        
        try {
          console.log(`Calculating distances from ${origin.address} to batch of ${batchDestinations.length} destinations`)
          
          const response = await new Promise<google.maps.DistanceMatrixResponse>((resolve, reject) => {
            service.getDistanceMatrix({
              origins: [{ lat: origin.lat, lng: origin.lng }],
              destinations: batchDestinations.map(dest => ({ lat: dest.lat, lng: dest.lng })),
              travelMode: google.maps.TravelMode.DRIVING,
              unitSystem: google.maps.UnitSystem.METRIC,
              avoidHighways: false,
              avoidTolls: false
            }, (response, status) => {
              console.log(`Distance Matrix API response status: ${status}`)
              if (status === google.maps.DistanceMatrixStatus.OK && response) {
                resolve(response)
              } else {
                reject(new Error(`Distance Matrix request failed: ${status}`))
              }
            })
          })

          // Process the response
          for (let k = 0; k < batchDestinations.length; k++) {
            const destination = batchDestinations[k]
            const element = response.rows[0].elements[k]
            
            if (element.status === 'OK') {
              matrix[origin.id][destination.id] = {
                distance: element.distance.value,
                duration: element.duration.value
              }
              console.log(`Distance from ${origin.address} to ${destination.address}: ${element.distance.text}, Duration: ${element.duration.text}`)
            } else {
              console.error(`Failed to get distance for ${origin.address} to ${destination.address}: ${element.status}`)
              // Use a fallback straight-line distance calculation
              const distance = calculateHaversineDistance(
                origin.lat, origin.lng, 
                destination.lat, destination.lng
              )
              // Estimate duration based on average speed of 50 km/h
              const duration = Math.round(distance / 50 * 3600)
              
              matrix[origin.id][destination.id] = {
                distance: Math.round(distance * 1000), // Convert km to meters
                duration: duration // seconds
              }
              console.log(`Using fallback distance calculation: ${distance.toFixed(2)} km, Est. duration: ${Math.round(duration / 60)} mins`)
            }
          }
          
          // Add a small delay between API calls to avoid rate limiting
          await new Promise(resolve => setTimeout(resolve, 300))
        } catch (error) {
          console.error('Error calculating distance matrix:', error)
          
          // Use fallback distance calculation for this batch
          for (let k = 0; k < batchDestinations.length; k++) {
            const destination = batchDestinations[k]
            
            // Use a fallback straight-line distance calculation
            const distance = calculateHaversineDistance(
              origin.lat, origin.lng, 
              destination.lat, destination.lng
            )
            // Estimate duration based on average speed of 50 km/h
            const duration = Math.round(distance / 50 * 3600)
            
            matrix[origin.id][destination.id] = {
              distance: Math.round(distance * 1000), // Convert km to meters
              duration: duration // seconds
            }
            console.log(`Using fallback distance for ${origin.address} to ${destination.address}: ${distance.toFixed(2)} km`)
          }
        }
      }
    }

    return matrix
  }
  
  // Haversine formula to calculate distance between two points on Earth
  const calculateHaversineDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371 // Radius of the Earth in km
    const dLat = (lat2 - lat1) * Math.PI / 180
    const dLon = (lon2 - lon1) * Math.PI / 180
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
    return R * c // Distance in km
  }

  // Nearest Neighbor algorithm for route optimization
  const optimizeRouteWithNearestNeighbor = (matrix: DistanceMatrix, startAddressId: string) => {
    const unvisited = new Set(Object.keys(matrix))
    const optimizedRoute: string[] = []
    let currentAddressId = startAddressId
    let totalDistance = 0
    let totalDuration = 0

    // Add the starting address
    optimizedRoute.push(currentAddressId)
    unvisited.delete(currentAddressId)

    // Find the nearest neighbor for each step
    while (unvisited.size > 0) {
      let nearestAddressId = ''
      let minDistance = Infinity

      // Convert Set to Array for iteration to avoid TypeScript error
      Array.from(unvisited).forEach(addressId => {
        const distance = matrix[currentAddressId][addressId].distance
        if (distance < minDistance) {
          minDistance = distance
          nearestAddressId = addressId
        }
      })

      // Add the nearest address to the route
      optimizedRoute.push(nearestAddressId)
      totalDistance += minDistance
      totalDuration += matrix[currentAddressId][nearestAddressId].duration
      
      // Update current address and remove from unvisited
      currentAddressId = nearestAddressId
      unvisited.delete(nearestAddressId)
    }

    return { optimizedRoute, totalDistance, totalDuration }
  }

  // Try different starting points to find the best route
  const findBestRoute = (matrix: DistanceMatrix) => {
    let bestRoute: string[] = []
    let bestDistance = Infinity
    let bestDuration = Infinity

    // Try each address as a starting point
    for (const startAddressId of Object.keys(matrix)) {
      const { optimizedRoute, totalDistance, totalDuration } = optimizeRouteWithNearestNeighbor(matrix, startAddressId)
      
      if (totalDistance < bestDistance) {
        bestRoute = optimizedRoute
        bestDistance = totalDistance
        bestDuration = totalDuration
      }
    }

    return { bestRoute, bestDistance, bestDuration }
  }

  // Calculate the total distance and duration of the current route
  const calculateCurrentRouteStats = (matrix: DistanceMatrix) => {
    if (addresses.length < 2) return { distance: 0, duration: 0 }
    
    let totalDistance = 0
    let totalDuration = 0

    for (let i = 0; i < addresses.length - 1; i++) {
      const currentId = addresses[i].id
      const nextId = addresses[i + 1].id
      
      if (matrix[currentId] && matrix[currentId][nextId]) {
        totalDistance += matrix[currentId][nextId].distance
        totalDuration += matrix[currentId][nextId].duration
      }
    }

    return { distance: totalDistance, duration: totalDuration }
  }

  // Calculate labor cost based on duration and hourly rate
  const calculateLaborCost = (durationInSeconds: number) => {
    // Convert seconds to hours and multiply by hourly rate
    const hours = durationInSeconds / 3600
    return hours * hourlyCost
  }

  // Add time spent at each address to the total duration
  const calculateTotalTimeWithStops = (durationInSeconds: number) => {
    // Add time spent at each address (if specified)
    const totalStopTime = addresses.reduce((total, address) => {
      // Convert minutes to seconds and add to total
      return total + ((address.time_spent || 0) * 60)
    }, 0)
    
    return durationInSeconds + totalStopTime
  }

  const handleOptimizeRoute = async () => {
    if (addresses.length < 2) {
      toast({
        title: "Not enough addresses",
        description: "You need at least 2 addresses to optimize a route",
        variant: "destructive"
      })
      return
    }

    if (!startingAddressId) {
      toast({
        title: "Starting address required",
        description: "Please select a starting address for your route",
        variant: "destructive"
      })
      return
    }
    
    setIsOptimizing(true)
    
    try {
      // Calculate distance matrix
      const matrix = await calculateDistanceMatrix(addresses)
      if (!matrix) {
        throw new Error("Failed to calculate distance matrix")
      }
      
      setDistanceMatrix(matrix)
      
      // Optimize route with the selected starting address
      const { optimizedRoute, totalDistance, totalDuration } = optimizeRouteWithNearestNeighbor(matrix, startingAddressId)
      
      // Get the current route stats
      const { distance: currentDistance, duration: currentDuration } = calculateCurrentRouteStats(matrix)
      
      // Calculate improvement percentage
      const improvementPercentage = currentDistance > 0 
        ? ((currentDistance - totalDistance) / currentDistance) * 100 
        : 0
      
      // Calculate labor cost
      const laborCost = calculateLaborCost(totalDuration)
      
      // Update stats
      setOptimizationStats({
        totalDistance,
        totalDuration,
        improvementPercentage,
        laborCost
      })
      
      // Reorder addresses based on optimized route
      const optimizedAddresses = optimizedRoute.map(id => 
        addresses.find(addr => addr.id === id)!
      )
      
      // Call the parent component's callback
      onOptimizeRoute(optimizedAddresses)
      
      toast({
        title: "Route optimized",
        description: `Optimized route with ${addresses.length} addresses`,
        variant: "default"
      })
    } catch (error) {
      console.error('Error optimizing route:', error)
      toast({
        title: "Error",
        description: "Failed to optimize route",
        variant: "destructive"
      })
    } finally {
      setIsOptimizing(false)
    }
  }

  const handleStartRoute = () => {
    if (!optimizationStats) {
      toast({
        title: "Optimize first",
        description: "Please optimize your route before starting navigation",
        variant: "destructive"
      })
      return
    }
    
    // Generate Google Maps URL with waypoints
    const origin = addresses[0]
    const destination = addresses[addresses.length - 1]
    const waypoints = addresses.slice(1, -1)
    
    let googleMapsUrl = `https://www.google.com/maps/dir/?api=1&origin=${origin.lat},${origin.lng}&destination=${destination.lat},${destination.lng}`
    
    if (waypoints.length > 0) {
      const waypointsString = waypoints
        .map(wp => `${wp.lat},${wp.lng}`)
        .join('|')
      
      googleMapsUrl += `&waypoints=${waypointsString}`
    }
    
    // Open Google Maps in a new tab
    window.open(googleMapsUrl, '_blank')
    
    toast({
      title: "Route started",
      description: "Navigation opened in Google Maps",
      variant: "default"
    })
  }

  const exportToGPX = () => {
    if (!optimizationStats) {
      toast({
        title: "Optimize first",
        description: "Please optimize your route before exporting",
        variant: "destructive"
      })
      return
    }
    
    setIsExporting(true)
    
    try {
      // Create GPX content
      let gpxContent = `<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="RoutePlanner Pro" xmlns="http://www.topografix.com/GPX/1/1">
  <metadata>
    <name>RoutePlanner Pro Optimized Route</name>
    <time>${new Date().toISOString()}</time>
  </metadata>
  <rte>
    <name>Optimized Route</name>\n`
      
      // Add route points
      addresses.forEach((address, index) => {
        gpxContent += `    <rtept lat="${address.lat}" lon="${address.lng}">
      <name>Stop ${index + 1}: ${address.address}</name>
      ${address.notes ? `<desc>${address.notes}</desc>` : ''}
    </rtept>\n`
      })
      
      // Close GPX file
      gpxContent += `  </rte>
</gpx>`
      
      // Create a blob and download link
      const blob = new Blob([gpxContent], { type: 'application/gpx+xml' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `route-${new Date().toISOString().slice(0, 10)}.gpx`
      document.body.appendChild(a)
      a.click()
      
      // Clean up
      setTimeout(() => {
        document.body.removeChild(a)
        URL.revokeObjectURL(url)
      }, 100)
      
      toast({
        title: "Export successful",
        description: "Route exported to GPX format",
        variant: "default"
      })
    } catch (error) {
      console.error('Error exporting to GPX:', error)
      toast({
        title: "Export failed",
        description: "Failed to export route to GPX format",
        variant: "destructive"
      })
    } finally {
      setIsExporting(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="bg-white p-4 rounded-lg border border-gray-200 mb-4">
        <div className="flex items-center mb-2">
          <Home className="h-4 w-4 text-gray-500 mr-2" />
          <h3 className="text-sm font-medium text-gray-700">Starting Address</h3>
        </div>
        <div className="mb-4">
          <Select 
            value={startingAddressId} 
            onValueChange={setStartingAddressId}
            disabled={addresses.length === 0}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Select a starting address" />
            </SelectTrigger>
            <SelectContent>
              {addresses.map((address) => (
                <SelectItem key={address.id} value={address.id}>
                  {address.address}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-xs text-gray-500 mt-1">
            Select the address where you'll start your route from
          </p>
        </div>
      </div>
      
      <div className="flex flex-col sm:flex-row gap-3">
        <Button 
          onClick={handleOptimizeRoute} 
          disabled={isOptimizing || addresses.length < 2}
          className="flex-1"
        >
          {isOptimizing ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Optimizing...
            </>
          ) : (
            <>
              <RotateCw className="mr-2 h-4 w-4" />
              Optimize Route
            </>
          )}
        </Button>
        
        <Button 
          onClick={handleStartRoute}
          disabled={!optimizationStats}
          variant="default"
          className="flex-1 bg-emerald-600 hover:bg-emerald-700"
        >
          <Play className="mr-2 h-4 w-4" />
          Start Route
        </Button>
        
        <Button
          onClick={exportToGPX}
          disabled={!optimizationStats || isExporting}
          variant="outline"
          className="flex-1"
        >
          {isExporting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Exporting...
            </>
          ) : (
            <>
              <Download className="mr-2 h-4 w-4" />
              Export GPX
            </>
          )}
        </Button>
      </div>
      
      {optimizationStats && (
        <div className="bg-gray-50 rounded-lg p-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white p-3 rounded-md border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-gray-500">Total Distance</p>
                <p className="text-lg font-semibold">{(optimizationStats.totalDistance / 1000).toFixed(1)} km</p>
              </div>
              <div className="w-8 h-8 rounded-full bg-blue-50 flex items-center justify-center">
                <Route className="h-4 w-4 text-blue-600" />
              </div>
            </div>
          </div>
          
          <div className="bg-white p-3 rounded-md border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-gray-500">Total Time</p>
                <p className="text-lg font-semibold">
                  {Math.floor(optimizationStats.totalDuration / 3600)}h {Math.floor((optimizationStats.totalDuration % 3600) / 60)}m
                </p>
              </div>
              <div className="w-8 h-8 rounded-full bg-amber-50 flex items-center justify-center">
                <Clock className="h-4 w-4 text-amber-600" />
              </div>
            </div>
          </div>
          
          <div className="bg-white p-3 rounded-md border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-gray-500">Improvement</p>
                <p className="text-lg font-semibold">{optimizationStats.improvementPercentage.toFixed(1)}%</p>
              </div>
              <div className="w-8 h-8 rounded-full bg-emerald-50 flex items-center justify-center">
                <TrendingDown className="h-4 w-4 text-emerald-600" />
              </div>
            </div>
          </div>
          
          <div className="bg-white p-3 rounded-md border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-gray-500">Labor Cost</p>
                <p className="text-lg font-semibold">€{optimizationStats.laborCost.toFixed(2)}</p>
              </div>
              <div className="w-8 h-8 rounded-full bg-purple-50 flex items-center justify-center">
                <DollarSign className="h-4 w-4 text-purple-600" />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

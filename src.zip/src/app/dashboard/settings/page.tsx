"use client"

import { Settings } from '@/components/dashboard/settings'

export default function SettingsPage() {
  return (
    <div className="container mx-auto py-6">
      <Settings />
    </div>
  )
}
